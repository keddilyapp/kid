<div class="loader loader_page_single">
    <x-loaders.loader-01/>
</div>
